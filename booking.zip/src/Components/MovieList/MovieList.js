import React from "react";
import { movies, seats } from "../Data";



const MovieList = () => {
  return (
    <div className="card-container">
        <div className="movie-card">
          <img className="movie-img" src={movies.image} alt=""/>
          <h2 className="movie-title">{movies.title}</h2>
          <p className="movie-lang">{movies.language}</p>
          <p className="movie-amount">{movies.amount}</p>
        </div>
    </div>
  )
}

export default MovieList;