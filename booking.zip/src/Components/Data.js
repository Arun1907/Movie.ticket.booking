import React from "react";

const movies = [
    { id: 1, image:'', title: 'Manjumel Boys', language: 'Tamil', amount: 'Rs.180/Per Seat' },
    { id: 2, image:'', title: 'The Ring', language: 'English', amount: 'Rs.180/Per Seat'},
    { id: 3, image:'', title: 'DeAr', language: 'Tamil', amount: 'Rs.180/Per Seat' },
    { id: 4, image:'', title: 'KungFu Panda 4', language: 'Tamil', amount: 'Rs.180/Per Seat' },
    { id: 5, image:'', title: 'Ayalaan', language: 'Tamil', amount: 'Rs.180/Per Seat' },
    { id: 6, image:'', title: 'Premalu', language: 'Tamil', amount: 'Rs.180/Per Seat' },
    { id: 7, image:'', title: 'Movie', language: 'Tamil', amount: 'Rs.180/Per Seat' },
    { id: 8, image:'', title: 'Movie2', language: 'Tamil', amount: 'Rs.180/Per Seat' },
];

const seats = [
    {
        row: "A",
        columns: [
          { id: 1, isAvailable: true },
          { id: 2, isAvailable: true },
          { id: 3, isAvailable: true },
          { id: 4, isAvailable: true },
          { id: 5, isAvailable: true },
          { id: 6, isAvailable: true },
          { id: 7, isAvailable: true },
          { id: 8, isAvailable: true },
          { id: 9, isAvailable: true },
          { id: 10, isAvailable: true },
        ],
      },

      {
        row: "B",
        columns: [
          { id: 1, isAvailable: true },
          { id: 2, isAvailable: true },
          { id: 3, isAvailable: true },
          { id: 4, isAvailable: true },
          { id: 5, isAvailable: true },
          { id: 6, isAvailable: true },
          { id: 7, isAvailable: true },
          { id: 8, isAvailable: true },
          { id: 9, isAvailable: true },
          { id: 10, isAvailable: true },
        ],
      },

      {
        row: "C",
        columns: [
          { id: 1, isAvailable: true },
          { id: 2, isAvailable: true },
          { id: 3, isAvailable: true },
          { id: 4, isAvailable: true },
          { id: 5, isAvailable: true },
          { id: 6, isAvailable: true },
          { id: 7, isAvailable: true },
          { id: 8, isAvailable: true },
          { id: 9, isAvailable: true },
          { id: 10, isAvailable: true },
        ],
      },

      {
        row: "D",
        columns: [
          { id: 1, isAvailable: true },
          { id: 2, isAvailable: true },
          { id: 3, isAvailable: true },
          { id: 4, isAvailable: true },
          { id: 5, isAvailable: true },
          { id: 6, isAvailable: true },
          { id: 7, isAvailable: true },
          { id: 8, isAvailable: true },
          { id: 9, isAvailable: true },
          { id: 10, isAvailable: true },
        ],
      },

      {
        row: "E",
        columns: [
          { id: 1, isAvailable: true },
          { id: 2, isAvailable: true },
          { id: 3, isAvailable: true },
          { id: 4, isAvailable: true },
          { id: 5, isAvailable: true },
          { id: 6, isAvailable: true },
          { id: 7, isAvailable: true },
          { id: 8, isAvailable: true },
          { id: 9, isAvailable: true },
          { id: 10, isAvailable: true },
        ],
      },
];


export {movies, seats};