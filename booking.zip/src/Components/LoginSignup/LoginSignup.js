import React, { useState } from "react";
import './LoginSignup.css'

const LoginSignup = ({setLogined}) => {
    const [action, setAction] = useState("Sign Up");

    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: ''
      });
      console.log("formData",formData)
      const [errors, setErrors] = useState({});
    
      const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData({
          ...formData, [name] : value
        });
        setErrors({
          ...errors, [name]: ''
        });
      }
    
      const validateForm = () => {
        let validationErrors = {};
        if(!formData.username.trim()){
          validationErrors.username = 'Username Required';
        }
        if(!formData.email.trim()){
          validationErrors.email = "E-mail Required";
        }
        if(!formData.password.trim()){
          validationErrors.password = 'Password Required';
        }
        return validationErrors;
      }
    
      const handleSubmit = (e) => {
        e.preventDefault();
        const errors = validateForm();
        if (Object.keys(errors).length > 0) {
          setErrors(errors);
          return;
        }
        if (action === "Sign Up") {
          // Handle sign up logic
          console.log("Sign up with formData: ", formData);
          setLogined(true)
        } else if (action === "Login") {
          // Handle login logic
          console.log("Login with formData: ", formData);

        }
      }

    return (
        <div className="container" onSubmit={handleSubmit}>
            <div className="header">
                <div className="text">{action}</div>
                <div className="underline"></div>
            </div>
            <div className="inputs">
                {action === "Login" ? <div></div> : <div className="input">
                    <input type="text" placeholder="Name" name="username" onChange={handleChange} />
                </div>}

                <div className="input">
                    <input type="email" placeholder="E-mail" name="email"  onChange={handleChange} />
                </div>
                <div className="input">
                    <input type="password" placeholder="Password" name="password"  onChange={handleChange}/>
                </div>
            </div>
            {action === "Sign Up" ? <div></div> : <div className="forgot-password">Forgot password? <span>Click here...</span></div>}

            <div className="submit-container">
                <div className={action === "Login" ? "submit gray" : "submit"} onClick={() => { setAction("Sign Up") }}>Sign Up</div>
                <div className={action === "Sign Up" ? "submit gray" : "submit"} onClick={() => { setAction("Login") }}>Login</div>
            </div>
        </div>
    )
}

export default LoginSignup