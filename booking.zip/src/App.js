//import { BrowserRouter as Router,Route,Redirect,Switch } from 'react-router-dom';
import React from 'react';
import './App.css';
//import LoginSignup from './Components/LoginSignup/LoginSignup';
import MovieList from './Components/MovieList/MovieList';
import { movies } from './Components/Data';
//import { useState } from 'react';

//const [logined,setLogined] = useState(false)
const App=()=> {
  return (
    <div>
      <MovieList 
      id={movies.id}
      title={movies.title}
      image 
      />
    </div>
  );
}

export default App;
/*
<Router>
        <Switch>
          <Route path='/login'>
            <LoginSignup setLogined={setLogined}/>
          </Route>
          <Route path='/movies'>
              {logined?<MovieList/> : <Redirect to= '/login' />}
          </Route>
          <Redirect from="/" to="/login" />
        </Switch>
      </Router>
      */